<?php

/**
 * @package    Switch Editor
 * @subpackage mod_switcheditor
 * @copyright  Copyright (C) 2012 Anything Digital. All rights reserved.
 * @copyright  Copyright (C) 2008 Netdream - Como,Italy. All rights reserved.
 * @license    GNU/GPLv2
 */
// no direct access
defined('_JEXEC') or die;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;

// include the language
Factory::getLanguage()->load('mod_switcheditor.sys', JPATH_ADMINISTRATOR);

// include the helper only once
require_once dirname(__FILE__) . '/helper.php';

if (modSwitchEditorHelper::isPluginEnabled())
{
	$version = new JVersion();
	$options = modSwitchEditorHelper::getEditorOptions();
	$value = Factory::getUser()->getParam('editor');
	$path = ModuleHelper::getLayoutPath('mod_switcheditor', $params->get('layout', 'default'));
	if (JFile::exists($path))
	{
	HTMLHelper::_('jquery.framework');

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();

$wa->registerAndUseStyle('switcheditor', 'switcheditor/switcheditor.css');
$wa->registerAndUseScript('switcheditor','switcheditor/switcheditor.js', [], ['defer' => true], ['core']);
		require $path;
	}
}
