<?php
/**
 * view.html.php
 *
 * php version 5
 *
 * @category  Joomla
 * @package   Joomla.Administrator
 * @author    Folcomedia <contact@folcomedia.fr>
 * @copyright 2014 Folcomedia
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 * @link      https://www.folcomedia.fr
 */
 

 
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;




jimport('joomla.application.component.view');

/**
 * Composant FMPackager - View FMPackager
 *
 * @category Joomla
 * @package  Joomla.Administrator
 * @author   Folcomedia <contact@folcomedia.fr>
 * @license  GNU General Public License version 2 or later; see LICENSE.txt
 * @link     https://www.folcomedia.fr
 
* class FMPackagerViewFMPackager extends JViewLegacy
 */

class FmpackagerViewFmpackager extends JViewLegacy

{

    /**
     * Affichage de la vue
     *
     * @return void
     */
    public function display($tpl = NULL)
    {

        // Paramètres page

$input = Factory::getApplication('administrator')->input; 

$option = $input->getString('option');
$view = $input->getString('fmpackager');


/*
$app = Factory::getApplication(); 
        $this->option = $app->input->getString('option');
        $this->view = $app->input->->getString('view', 'fmpackager');
*/


/*
$option = $input->getString('option', '');
$view = $input->getString('fmpackager');
*/

//$view       = $input->get('view', '');

//NO $view   = $this->input->getString('view', '');

//$this->help_search = Factory::getApplication()->input->getString('helpsearch');
        

        // Données de la page
        $this->extensions = $this->getModel()->getExtensions();

        // Affichage
       // $this->toolbar();
       
      
        //parent::display();
        return parent::display($tpl);

    }

    /**
     * Affichage de la barre d'outil
     *
     * @return void
     */
    private function toolbar()
    {

        $joomlaVersion = new JVersion();
        JToolBarHelper::title(JText::_('COM_FMPACKAGER'), $joomlaVersion->getShortVersion() >= 3 ? 'briefcase' : 'install');

    }

}