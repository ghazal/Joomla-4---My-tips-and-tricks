<?php
/**
 * fmpackager.php
 *
 * php version 5
 *
 * @category  Joomla
 * @package   Joomla.Administrator
 * @author    Folcomedia <contact@folcomedia.fr>
 * @copyright 2014 Folcomedia
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 * @link      https://www.folcomedia.fr
 */
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;

// Chargement jQuery
jimport('joomla.version');
$joomlaVersion = new JVersion();




// Exécution tâche courante
$controller = JControllerLegacy::getInstance('fmpackager');
$controller->execute(Factory::getApplication()->input->get('task'));
$controller->redirect();